package com.blackdata.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 12, 10), PANEL = Color.rgb(18, 25, 21);
    private final int GREEN = Color.rgb(57, 255, 130), MUTED = Color.rgb(164, 185, 172);
    private LinearLayout root;
    private TextView status, result;
    private EditText host;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        showNetwork();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        d.setStroke(1, Color.rgb(40, 70, 52));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22, 24, 22, 28);
        scroll.addView(root); setContentView(scroll);

        TextView logo = text("BLACK DATA", 29, GREEN, true);
        logo.setLetterSpacing(0.12f); root.addView(logo);
        TextView subtitle = text("NETWORK DIAGNOSTICS  /  ANDROID", 11, MUTED, true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = 5; sp.bottomMargin = 24; root.addView(subtitle, sp);

        section("01  /  CONNECTION STATUS");
        status = text("Checking network…", 16, Color.WHITE, true);
        panel(status);
        Button refresh = button("REFRESH NETWORK STATUS");
        refresh.setOnClickListener(v -> showNetwork()); root.addView(refresh, margins());

        section("02  /  DNS LOOKUP");
        host = new EditText(this); host.setSingleLine(true); host.setText("example.com");
        host.setHint("example.com"); host.setHintTextColor(MUTED); host.setTextColor(Color.WHITE);
        host.setTextSize(16); host.setPadding(14, 8, 14, 8); host.setBackground(shape(PANEL, 12));
        root.addView(host, margins());
        Button dns = button("RESOLVE DNS"); dns.setOnClickListener(v -> runDns()); root.addView(dns, margins());

        section("03  /  CONNECTIVITY TEST");
        TextView note = text("Tests whether a host can be reached. Android or the network may block ICMP, so a failed test does not always mean the host is offline.", 13, MUTED, false);
        note.setLineSpacing(3, 1); root.addView(note, margins());
        Button ping = button("TEST HOST REACHABILITY"); ping.setOnClickListener(v -> runReachability()); root.addView(ping, margins());

        section("RESULT LOG");
        result = text("Ready. Choose a diagnostic above.", 14, GREEN, false);
        result.setPadding(15, 16, 15, 16); result.setBackground(shape(PANEL, 12));
        root.addView(result, margins());
        TextView footer = text("BLACK DATA  •  LOCAL DIAGNOSTICS ONLY", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fp = margins(); fp.topMargin = 28; root.addView(footer, fp);
    }

    private void section(String title) {
        TextView t = text(title, 12, GREEN, true); t.setLetterSpacing(0.07f);
        LinearLayout.LayoutParams p = margins(); p.topMargin = 18; p.bottomMargin = 9; root.addView(t, p);
    }

    private void panel(TextView v) {
        v.setPadding(15, 16, 15, 16); v.setBackground(shape(PANEL, 12)); root.addView(v, margins());
    }

    private LinearLayout.LayoutParams margins() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 9; return p;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(BG); b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(GREEN, 12));
        b.setPadding(12, 9, 12, 9); return b;
    }

    private String getHost() {
        String s = host.getText().toString().trim();
        if (s.startsWith("https://")) s = s.substring(8);
        if (s.startsWith("http://")) s = s.substring(7);
        int slash = s.indexOf('/'); if (slash >= 0) s = s.substring(0, slash);
        return s;
    }

    private void hideKeyboard() {
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
          .hideSoftInputFromWindow(host.getWindowToken(), 0);
        host.clearFocus();
    }

    private void runDns() {
        String target = getHost();
        if (target.isEmpty() || target.contains(" ")) { result.setText("Enter a valid hostname, such as example.com"); return; }
        hideKeyboard(); result.setText("Resolving " + target + "…");
        worker.execute(() -> {
            String out;
            try {
                InetAddress[] addresses = InetAddress.getAllByName(target);
                StringBuilder b = new StringBuilder("DNS RESULTS FOR ").append(target).append("\n");
                for (InetAddress a : addresses) b.append("• ").append(a.getHostAddress()).append("\n");
                out = b.toString();
            } catch (Exception e) { out = "DNS lookup failed: " + e.getClass().getSimpleName() + "\n" + e.getMessage(); }
            final String answer = out;
            runOnUiThread(() -> result.setText(answer));
        });
    }

    private void runReachability() {
        String target = getHost();
        if (target.isEmpty() || target.contains(" ")) { result.setText("Enter a valid hostname first."); return; }
        hideKeyboard(); result.setText("Testing reachability of " + target + "…");
        worker.execute(() -> {
            long start = System.currentTimeMillis(); String out;
            try {
                InetAddress address = InetAddress.getByName(target);
                boolean reachable = address.isReachable(3500);
                long ms = System.currentTimeMillis() - start;
                out = "HOST: " + target + "\nIP: " + address.getHostAddress() +
                      "\nReachable: " + (reachable ? "YES" : "NO / ICMP MAY BE BLOCKED") +
                      "\nElapsed: " + ms + " ms";
            } catch (Exception e) { out = "Connection test failed: " + e.getClass().getSimpleName() + "\n" + e.getMessage(); }
            final String answer = out;
            runOnUiThread(() -> result.setText(answer));
        });
    }

    private void showNetwork() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        Network network = cm == null ? null : cm.getActiveNetwork();
        NetworkCapabilities caps = network == null ? null : cm.getNetworkCapabilities(network);
        boolean connected = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        String type = "Unknown";
        if (caps != null) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) type = "Wi-Fi";
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) type = "Mobile data";
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) type = "Ethernet";
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) type = "VPN";
        }
        status.setText((connected ? "● ONLINE" : "● OFFLINE / NO INTERNET") + "\nConnection type: " + type);
        status.setTextColor(connected ? GREEN : Color.rgb(255, 115, 115));
        result.setText("Network status refreshed.\nInternet capability: " + (connected ? "available" : "not detected") + "\nTransport: " + type);
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
}
